/**
 * 
 */
window.addEventListener('load',()=>{
	const params=(new URL(document.location)).searchParams;
	const empid=params.get('empid');
	localStorage.setItem("empId",empid)
	document.getElementById('result_name').innerHTML=localStorage.getItem("empId");
})